"""CoinMarketCap API Configuration"""
COINMARKETCAP_URL=''
COINMARKETCAP_API_KEY=''

"""Infura URL to connect to Ethereum network using Web3""" 
INFURA_URL = ''