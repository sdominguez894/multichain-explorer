from enum import Enum

class Resource(Enum):
    address = "address"
    block = "block"
    transaction = "transaction"