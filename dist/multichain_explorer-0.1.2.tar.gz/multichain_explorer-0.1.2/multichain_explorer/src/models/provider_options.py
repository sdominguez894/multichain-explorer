class ProviderOptions():
    raw: bool

    def __init__(self, raw = False):
        self.raw = raw
